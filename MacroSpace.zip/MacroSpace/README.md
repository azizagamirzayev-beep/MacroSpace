# Macro Space v2
Keymap overlay (edit keymap, enable/disable, profile multi-select, minimize, drag), player overlay (play/pause/stop/loop + own profile selector),
editable macro buttons (color, opacity, size, text), double/triple/hold taps, swipe point picking, overlay style editor.
Build: GitHub Actions workflow "Build APK" (see .github/workflows/build.yml in the repo root).
