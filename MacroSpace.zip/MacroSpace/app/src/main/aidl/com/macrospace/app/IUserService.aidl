package com.macrospace.app;

import com.macrospace.app.ITouchListener;

interface IUserService {
    void destroy() = 16777114;

    // Prepares touch injection and starts watching the touchscreen. Returns "OK" or an error text.
    String start(ITouchListener listener);
    void stopReading();

    // Real touches injected with shell privileges (they do not cancel the user's own touch).
    void tap(int x, int y, int holdMs, int count, int gapMs);
    void swipe(int x1, int y1, int x2, int y2, int durMs);
}
