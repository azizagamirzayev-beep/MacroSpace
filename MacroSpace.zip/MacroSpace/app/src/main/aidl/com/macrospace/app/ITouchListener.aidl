package com.macrospace.app;

// Called from the privileged process for every finger that goes down (action 0) or up (action 1).
// x and y are normalized 0..10000 in the touchscreen's natural orientation.
oneway interface ITouchListener {
    void onTouch(int action, int slot, int x, int y);
}
