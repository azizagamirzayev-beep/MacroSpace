package com.macrospace.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ArrayAdapter
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

class MacroEditorActivity : Activity() {
    private lateinit var m: Macro
    private var inList = false
    private lateinit var nameE: EditText
    private lateinit var profB: Button
    private lateinit var repE: EditText
    private lateinit var loopC: CheckBox
    private lateinit var touchS: Spinner
    private lateinit var stepsBox: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val ex = Store.macros.find { it.id == intent.getStringExtra("id") }
        if (ex != null) { m = ex; inList = true } else {
            m = Macro(
                name = "Macro ${Store.macros.size + 1}",
                profileId = Store.selected.firstOrNull() ?: Store.profiles[0].id
            )
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        root.addView(label(if (inList) "Edit macro" else "New macro", 26f, Color.WHITE, true))

        val c1 = card()
        nameE = field("Macro name", m.name)
        c1.addView(nameE)
        profB = btn("Profile: " + Store.profileName(m.profileId)) {
            val names = Store.profiles.map { it.name }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Choose profile")
                .setItems(names) { _, i ->
                    m.profileId = Store.profiles[i].id
                    profB.text = "Profile: " + Store.profileName(m.profileId)
                }.show()
        }
        c1.addView(profB)
        c1.addView(label("Repeat count", 12f, C_SUB))
        repE = field("1", m.repeat.toString(), true)
        c1.addView(repE)
        loopC = CheckBox(this).apply {
            text = "Loop until stopped (tap the button again)"
            setTextColor(Color.WHITE); isChecked = m.loop
        }
        c1.addView(loopC)
        c1.addView(label("When you touch this macro's button", 12f, C_SUB))
        touchS = Spinner(this)
        val ad = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            arrayOf(
                "Block original touch (button takes the touch)",
                "Don't block (needs Privileged mode, else a quick tap is replayed)",
                "Don't block, no touch trigger (play from Player)"
            )
        )
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        touchS.adapter = ad
        touchS.setSelection(m.touch.coerceIn(0, 2))
        c1.addView(touchS)
        root.addView(c1, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val c2 = card()
        c2.addView(label("Steps (tap a step for options)", 16f, Color.WHITE, true))
        stepsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c2.addView(stepsBox)
        c2.addView(rowOf(
            btn("+ Tap") { stepDialog("tap", Step("tap", 500, 500, ms = 50, n = 1)) { m.steps.add(it); refreshSteps() } },
            btn("+ Double") { stepDialog("tap", Step("tap", 500, 500, ms = 40, n = 2, gap = 80)) { m.steps.add(it); refreshSteps() } },
            btn("+ Triple") { stepDialog("tap", Step("tap", 500, 500, ms = 40, n = 3, gap = 80)) { m.steps.add(it); refreshSteps() } }
        ))
        c2.addView(rowOf(
            btn("+ Hold") { stepDialog("tap", Step("tap", 500, 500, ms = 800, n = 1)) { m.steps.add(it); refreshSteps() } },
            btn("+ Swipe") { stepDialog("swipe", null) { m.steps.add(it); refreshSteps() } },
            btn("+ Wait") { stepDialog("wait", null) { m.steps.add(it); refreshSteps() } }
        ))
        c2.addView(btn("\u25CF Record taps and swipes", true) { record() })
        root.addView(c2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        root.addView(rowOf(
            btn("Save", true) { commit(); finish() },
            btn("Clear steps") { m.steps.clear(); refreshSteps() }
        ), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        setContentView(ScrollView(this).apply { setBackgroundColor(C_BG); addView(root) })
    }

    override fun onResume() { super.onResume(); refreshSteps() }

    override fun onPause() {
        super.onPause()
        if (inList) commit()
    }

    private fun commit() {
        m.name = nameE.text.toString().ifBlank { "Macro" }
        m.repeat = repE.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
        m.loop = loopC.isChecked
        m.touch = touchS.selectedItemPosition.coerceIn(0, 2)
        if (!inList) { Store.macros.add(m); inList = true; intent.putExtra("id", m.id) }
        Store.selected.add(m.profileId)
        Store.save()
        MacroService.instance?.refreshButtons()
    }

    private fun record() {
        val s = MacroService.instance
        if (s == null) {
            toast("Turn on Macro Space in Accessibility settings first")
            return
        }
        commit()
        toast("Open your game, do your taps and swipes, then press Stop recording")
        s.startRecording(m.id)
        moveTaskToBack(true)
    }

    private fun refreshSteps() {
        stepsBox.removeAllViews()
        if (m.steps.isEmpty()) stepsBox.addView(label("No steps yet", 13f, C_SUB))
        m.steps.forEachIndexed { i, s ->
            stepsBox.addView(TextView(this).apply {
                text = "${i + 1}. ${s.label()}"
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = roundBg(C_CARD2, dp(8))
                setOnClickListener { stepMenu(i) }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        }
    }

    private fun stepMenu(i: Int) {
        AlertDialog.Builder(this).setItems(arrayOf("Edit", "Move up", "Move down", "Delete")) { _, w ->
            when (w) {
                0 -> stepDialog(m.steps[i].type, m.steps[i]) { m.steps[i] = it; refreshSteps() }
                1 -> if (i > 0) { m.steps.add(i - 1, m.steps.removeAt(i)); refreshSteps() }
                2 -> if (i < m.steps.size - 1) { m.steps.add(i + 1, m.steps.removeAt(i)); refreshSteps() }
                3 -> { m.steps.removeAt(i); refreshSteps() }
            }
        }.show()
    }

    private fun stepDialog(type: String, s: Step?, onOk: (Step) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val f = mutableMapOf<String, EditText>()
        fun add(key: String, title: String, v: Long) {
            box.addView(label(title, 12f, C_SUB))
            val e = field("", v.toString(), true)
            f[key] = e; box.addView(e)
        }
        fun pick(text: String, count: Int) {
            box.addView(btn(text) {
                val svc = MacroService.instance
                if (svc == null) { toast("Turn on Macro Space in Accessibility settings first"); return@btn }
                val keys = listOf("x1", "y1", "x2", "y2")
                val init = mutableListOf<Pair<Int, Int>>()
                for (i in 0 until count) {
                    val x = f[keys[i * 2]]?.text?.toString()?.toIntOrNull()
                    val y = f[keys[i * 2 + 1]]?.text?.toString()?.toIntOrNull()
                    if (x != null && y != null) init.add(Pair(x, y))
                }
                svc.pickPoints(count, init, true) { pts ->
                    pts.forEachIndexed { i, pt ->
                        f[keys[i * 2]]?.setText(pt.first.toString())
                        f[keys[i * 2 + 1]]?.setText(pt.second.toString())
                    }
                }
                moveTaskToBack(true)
            })
        }
        when (type) {
            "tap" -> {
                add("x1", "X (pixels)", (s?.x1 ?: 500).toLong())
                add("y1", "Y (pixels)", (s?.y1 ?: 500).toLong())
                pick("Place point on screen (drag marker)", 1)
                add("n", "Taps: 1 = single, 2 = double, 3 = triple", (s?.n ?: 1).toLong())
                add("ms", "Hold time of each tap (ms). Use 500+ for a long press", s?.ms ?: 50L)
                add("gap", "Pause between taps (ms)", s?.gap ?: 60L)
            }
            "swipe" -> {
                add("x1", "From X", (s?.x1 ?: 500).toLong())
                add("y1", "From Y", (s?.y1 ?: 800).toLong())
                add("x2", "To X", (s?.x2 ?: 500).toLong())
                add("y2", "To Y", (s?.y2 ?: 400).toLong())
                pick("Place from and to on screen (drag markers)", 2)
                add("ms", "Duration (ms)", s?.ms ?: 300L)
            }
            else -> add("ms", "Delay (ms)", s?.ms ?: 500L)
        }
        AlertDialog.Builder(this).setTitle(
            when (type) { "tap" -> "Tap / double / triple / hold"; "swipe" -> "Swipe"; else -> "Wait" }
        )
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ ->
                fun g(k: String, d: Long) = f[k]?.text?.toString()?.toLongOrNull() ?: d
                onOk(Step(
                    type, g("x1", 0).toInt(), g("y1", 0).toInt(), g("x2", 0).toInt(), g("y2", 0).toInt(),
                    g("ms", 50), g("n", 1).toInt().coerceIn(1, 10), g("gap", 60)
                ))
            }
            .setNegativeButton("Cancel", null).show()
    }
}
