package com.macrospace.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

class MacroService : AccessibilityService() {
    companion object {
        var instance: MacroService? = null
    }

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var barOn = false
    private var barMin = false
    private var playerOn = false
    private var playerMin = false
    private var barV: View? = null
    private var playerV: View? = null
    private var panel: View? = null
    private var panelKind: String? = null
    private var recorder: View? = null
    private var picking = false
    private val pickerWins = mutableListOf<View>()

    private val buttons = mutableMapOf<String, TextView>()
    private val runners = mutableMapOf<String, Runner>()
    private var enabled = true
    private var editing = false
    private var barRestyle: (() -> Unit)? = null
    private var playerRestyle: (() -> Unit)? = null
    private val playlist = Playlist()

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Store.init(this)
        Priv.init(this)
    }

    private val clampRunnable = Runnable { clampAll() }

    // Window changes (screen lock/unlock, rotation) can leave floating windows off screen: pull them back.
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        h.removeCallbacks(clampRunnable)
        h.postDelayed(clampRunnable, 400)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        h.removeCallbacks(clampRunnable)
        h.postDelayed(clampRunnable, 300)
    }
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay(); hidePlayer(); instance = null
        return super.onUnbind(intent)
    }

    private fun lp(w: Int, hgt: Int, focusable: Boolean = false): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!focusable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        return WindowManager.LayoutParams(
            w, hgt, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // draw under the camera cut-out too, so coordinates are real screen coordinates
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return Pair(b.width(), b.height())
        }
        val dm = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    private fun clampView(v: View?) {
        if (v == null) return
        val p = v.layoutParams as? WindowManager.LayoutParams ?: return
        if (p.gravity != (Gravity.TOP or Gravity.START)) return
        val size = screenSize()
        val nx = p.x.coerceIn(0, maxOf(0, size.first - v.width))
        val ny = p.y.coerceIn(0, maxOf(0, size.second - v.height))
        if (nx != p.x || ny != p.y) {
            p.x = nx; p.y = ny
            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
        }
    }

    private fun clampAll() {
        clampView(barV)
        clampView(playerV)
        pickerWins.toList().forEach { clampView(it) }
    }

    private fun sc(v: Int): Int = (dp(v) * Store.ui.barScale / 100f).toInt()
    private fun sf(v: Float): Float = v * Store.ui.barScale / 100f

    private fun rm(v: View?) {
        if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
    }

    private fun appIntent(cls: Class<*>) = Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun openEditor(macroId: String) {
        closePanel()
        startActivity(
            appIntent(MacroEditorActivity::class.java).putExtra("id", macroId)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    // ---------------- Bars (keymap bar + player bar) ----------------

    fun showOverlay() {
        barOn = true; barMin = false; enabled = true; editing = false
        rebuildBars(); refreshButtons()
    }

    fun hideOverlay() {
        stopAll()
        barOn = false; editing = false
        closePanel()
        rebuildBars()
        refreshButtons()
    }

    fun showPlayer() { playerOn = true; playerMin = false; rebuildBars() }

    fun hidePlayer() {
        playlist.stop()
        playerOn = false
        if (panelKind == "pprof") closePanel()
        rebuildBars()
    }

    fun overlayVisible() = barOn
    fun playerVisible() = playerOn

    /** Re-creates the bar windows, e.g. after style or text changes. */
    fun rebuildBars() {
        rm(barV); barV = null
        rm(playerV); playerV = null
        val u = Store.ui
        if (barOn) {
            val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            p.x = if (u.barX < 0) dp(8) else u.barX
            p.y = if (u.barY < 0) dp(24) else u.barY
            val v = if (barMin) buildMini(p, "\u2630", { barMin = false; rebuildBars() }) { u.barX = p.x; u.barY = p.y; Store.save() }
            else buildBar(p)
            wm.addView(v, p); barV = v
        }
        if (playerOn) {
            val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            p.x = if (u.playX < 0) dp(8) else u.playX
            p.y = if (u.playY < 0) dp(90) else u.playY
            val v = if (playerMin) buildMini(p, "\u25B6", { playerMin = false; rebuildBars() }) { u.playX = p.x; u.playY = p.y; Store.save() }
            else buildPlayer(p)
            wm.addView(v, p); playerV = v
        }
    }

    private fun attachDrag(handle: View, target: View, p: WindowManager.LayoutParams, onClick: (() -> Unit)?, onEnd: () -> Unit) =
        attachDragFull(handle, target, p, onClick, null, onEnd)

    private fun attachDragFull(
        handle: View, target: View, p: WindowManager.LayoutParams,
        onClick: (() -> Unit)?, onMove: (() -> Unit)?, onEnd: () -> Unit
    ) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = (e.rawX - dx).toInt(); val ddy = (e.rawY - dy).toInt()
                    if (abs(ddx) > 8 || abs(ddy) > 8) moved = true
                    if (moved) {
                        p.x = sx + ddx; p.y = sy + ddy
                        try { wm.updateViewLayout(target, p) } catch (_: Exception) {}
                        onMove?.invoke()
                    }
                }
                MotionEvent.ACTION_UP -> { if (moved) onEnd() else onClick?.invoke() }
            }
            true
        }
    }

    private fun barBox(): LinearLayout {
        val u = Store.ui
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(sc(4), sc(4), sc(6), sc(4))
            background = roundBg(argb(u.barColor, u.barAlpha), sc(10))
        }
    }

    private fun barText(t: String): TextView = TextView(this).apply {
        text = if (t.isBlank()) "\u00B7" else t
        setTextColor(opaque(Store.ui.textColor)); textSize = sf(13f)
        setPadding(sc(9), sc(6), sc(9), sc(6))
        setSingleLine(true)
    }

    private fun buildMini(p: WindowManager.LayoutParams, glyph: String, onRestore: () -> Unit, onEnd: () -> Unit): View {
        val u = Store.ui
        val t = TextView(this).apply {
            text = glyph; gravity = Gravity.CENTER; textSize = sf(16f)
            setTextColor(opaque(u.textColor))
            background = roundBg(argb(u.barColor, u.barAlpha), sc(20))
            minWidth = sc(40); minHeight = sc(40)
        }
        attachDrag(t, t, p, onRestore, onEnd)
        return t
    }

    private fun buildBar(p: WindowManager.LayoutParams): View {
        val u = Store.ui
        val txt = opaque(u.textColor); val acc = opaque(u.accent)
        val row = barBox()
        val grip = barText("\u2630")
        val edit = barText(u.lblEdit)
        val en = barText(u.lblEnable)
        val dis = barText(u.lblDisable)
        val prof = barText(u.lblProfiles + " \u25BE")
        val more = barText("\u2022\u2022\u2022")
        barRestyle = {
            edit.text = if (editing) u.lblDone else u.lblEdit
            en.background = if (enabled) roundBg(txt, dp(8)) else null
            en.setTextColor(if (enabled) acc else txt)
            dis.background = if (!enabled) roundBg(txt, dp(8)) else null
            dis.setTextColor(if (!enabled) acc else txt)
        }
        edit.setOnClickListener {
            editing = !editing
            if (editing) enabled = true else closePanel()
            barRestyle?.invoke(); refreshButtons()
        }
        en.setOnClickListener { enabled = true; barRestyle?.invoke(); refreshButtons() }
        dis.setOnClickListener {
            enabled = false; editing = false; closePanel(); stopAll(); barRestyle?.invoke(); refreshButtons()
        }
        prof.setOnClickListener {
            togglePanel("prof") { buildProfilePicker(this, Store.selected) { refreshButtons() }.also { addClose(it) } }
        }
        more.setOnClickListener { togglePanel("menu") { buildMenu() } }
        listOf(grip, edit, en, dis, prof, more).forEach { row.addView(it) }
        attachDrag(grip, row, p, { closePanel(); barMin = true; rebuildBars() }) { u.barX = p.x; u.barY = p.y; Store.save() }
        barRestyle?.invoke()
        return row
    }

    private fun buildPlayer(p: WindowManager.LayoutParams): View {
        val u = Store.ui
        val txt = opaque(u.textColor); val acc = opaque(u.accent)
        val row = barBox()
        val grip = barText("\u2630")
        val play = barText(u.lblPlay)
        val pause = barText(u.lblPause)
        val stop = barText(u.lblStop)
        val loop = barText("\u21BB")
        val prof = barText(u.lblProfiles + " \u25BE")
        val close = barText("\u2715")
        playerRestyle = {
            val on = playlist.state == 1; val ps = playlist.state == 2
            play.background = if (on) roundBg(txt, dp(8)) else null
            play.setTextColor(if (on) acc else txt)
            pause.background = if (ps) roundBg(txt, dp(8)) else null
            pause.setTextColor(if (ps) acc else txt)
            loop.background = if (playlist.loopAll) roundBg(txt, dp(8)) else null
            loop.setTextColor(if (playlist.loopAll) acc else txt)
        }
        play.setOnClickListener { playlist.play() }
        pause.setOnClickListener { playlist.pause() }
        stop.setOnClickListener { playlist.stop() }
        loop.setOnClickListener { playlist.loopAll = !playlist.loopAll; playerRestyle?.invoke() }
        prof.setOnClickListener {
            togglePanel("pprof") { buildProfilePicker(this, Store.playSelected) {}.also { addClose(it) } }
        }
        close.setOnClickListener { hidePlayer() }
        listOf(grip, play, pause, stop, loop, prof, close).forEach { row.addView(it) }
        attachDrag(grip, row, p, { if (panelKind == "pprof") closePanel(); playerMin = true; rebuildBars() }) { u.playX = p.x; u.playY = p.y; Store.save() }
        playerRestyle?.invoke()
        return row
    }

    // ---------------- Panels (popups) ----------------

    private fun addClose(box: LinearLayout) {
        box.addView(TextView(this).apply {
            text = "Close"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
            setOnClickListener { closePanel() }
        })
    }

    private fun togglePanel(kind: String, build: () -> View) {
        if (panelKind == kind) { closePanel(); return }
        showPanel(kind, build())
    }

    private fun showPanel(kind: String, content: View) {
        closePanel()
        val width = dp(300)
        val sv = ScrollView(this).apply {
            addView(content)
            background = roundBg(0xF01B1F27.toInt(), dp(12))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        content.measure(
            View.MeasureSpec.makeMeasureSpec(width - dp(12), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxH = (resources.displayMetrics.heightPixels * 0.75).toInt()
        val height = min(content.measuredHeight + dp(12), maxH)
        val p = lp(width, height, true)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(70)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(sv, p)
        panel = sv; panelKind = kind
    }

    private fun closePanel() { rm(panel); panel = null; panelKind = null }

    private fun buildMenu(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        fun item(t: String, a: () -> Unit) {
            box.addView(TextView(this).apply {
                text = t; textSize = 15f; setTextColor(Color.WHITE)
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setOnClickListener { a() }
            })
        }
        item("Minimize (or tap \u2630)") { closePanel(); barMin = true; rebuildBars() }
        item("Overlay style") {
            showPanel("style", buildOverlayStyleEditor(this, { rebuildBars() }, { closePanel() }))
        }
        item("Open app") { closePanel(); startActivity(appIntent(MainActivity::class.java)) }
        item(if (playerOn) "Hide player" else "Show player") {
            closePanel()
            if (playerOn) hidePlayer() else showPlayer()
        }
        item("Close overlay") { hideOverlay() }
        return box
    }

    private fun showMacroPanel(m: Macro) {
        val content = buildMacroStyleEditor(
            this, m,
            { buttons[m.id]?.let { styleButton(m, it, runners.containsKey(m.id)) }; Store.save() },
            { openEditor(m.id) },
            { closePanel() }
        )
        showPanel("macro:" + m.id, content)
    }

    // ---------------- Macro buttons ----------------

    fun refreshButtons() {
        buttons.values.forEach { rm(it) }
        buttons.clear()
        if (!barOn || !enabled) {
            if (!barOn) runners.values.forEach { it.stop() }
            return
        }
        val visible = Store.macros.filter { it.profileId in Store.selected }
        val ids = visible.map { it.id }.toSet()
        runners.keys.filter { it !in ids }.forEach { runners.remove(it)?.stop() }
        visible.forEachIndexed { i, m ->
            if (m.btnX < 0) { m.btnX = dp(60) + i * dp(70); m.btnY = dp(140) }
            addMacroButton(m)
        }
    }

    private fun styleButton(m: Macro, b: TextView, running: Boolean) {
        val w = dp(m.w); val hh = dp(m.h)
        val r = (min(w, hh) / 2f) * (m.corner / 100f)
        b.background = GradientDrawable().apply {
            setColor(argb(m.color, m.alpha)); cornerRadius = r
            if (running) setStroke(dp(3), Color.WHITE)
        }
        b.text = if (m.label.isBlank()) m.name else m.label
        val p = b.tag as WindowManager.LayoutParams
        if (p.width != w || p.height != hh) {
            p.width = w; p.height = hh
            try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
        }
    }

    private fun addMacroButton(m: Macro) {
        val b = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 11f
            setTextColor(Color.WHITE); maxLines = 2
            setPadding(dp(4), 0, dp(4), 0)
        }
        val p = lp(dp(m.w), dp(m.h))
        p.x = m.btnX; p.y = m.btnY
        // "pass through only": the button never takes touches (except while editing the keymap)
        if (!editing && (m.touch == 2 || (m.touch == 1 && Priv.ready))) p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        b.tag = p
        styleButton(m, b, runners.containsKey(m.id))
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false
                    if (!editing && m.touch == 1) tapThrough(m, b, p, e.rawX, e.rawY)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (editing) {
                        val ddx = (e.rawX - dx).toInt(); val ddy = (e.rawY - dy).toInt()
                        if (abs(ddx) > 8 || abs(ddy) > 8) moved = true
                        if (moved) { p.x = sx + ddx; p.y = sy + ddy; wm.updateViewLayout(v, p) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (editing) {
                        if (moved) { m.btnX = p.x; m.btnY = p.y; Store.save() } else showMacroPanel(m)
                    } else if (m.touch == 0) toggleRun(m)
                }
            }
            true
        }
        wm.addView(b, p)
        buttons[m.id] = b
    }

    /**
     * Tap-through mode: the button lets the touch go to the game by sending a quick tap at the same
     * spot (the button is made untouchable for a moment), then starts/stops the macro.
     */
    private fun tapThrough(m: Macro, b: View, p: WindowManager.LayoutParams, x: Float, y: Float) {
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
        h.postDelayed({
            val path = Path().apply { moveTo(x, y) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build()
            val restore: () -> Unit = {
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                try { wm.updateViewLayout(b, p) } catch (_: Exception) {}
                if (buttons[m.id] === b) toggleRun(m)
            }
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { restore() }
                override fun onCancelled(d: GestureDescription?) { restore() }
            }, null)
            if (!ok) restore()
        }, 40)
    }

    // ---------------- Running macros ----------------

    private fun toggleRun(m: Macro) {
        val r = runners.remove(m.id)
        val b = buttons[m.id]
        if (r != null) { r.stop(); if (b != null) styleButton(m, b, false); return }
        if (b != null) styleButton(m, b, true)
        val nr = Runner(m, false) {
            h.post {
                runners.remove(m.id)
                buttons[m.id]?.let { styleButton(m, it, false) }
            }
        }
        runners[m.id] = nr
        nr.start()
    }

    private fun stopAll() {
        runners.values.forEach { it.stop() }
        runners.clear()
        for ((id, b) in buttons) {
            Store.macros.find { it.id == id }?.let { styleButton(it, b, false) }
        }
    }

    private inner class Runner(val m: Macro, val once: Boolean, val onDone: () -> Unit) {
        var stopped = false
        var paused = false
        var pending = false
        var idx = 0
        var round = 0
        fun stop() { stopped = true }
        fun resume() {
            paused = false
            if (pending) { pending = false; next() }
        }
        fun start() = next()
        fun next() {
            if (stopped) return
            if (paused) { pending = true; return }
            if (m.steps.isEmpty()) { onDone(); return }
            if (idx >= m.steps.size) {
                idx = 0; round++
                if ((once || !m.loop) && round >= m.repeat.coerceAtLeast(1)) { onDone(); return }
            }
            val s = m.steps[idx++]
            if (s.type == "wait") h.postDelayed({ next() }, s.ms) else dispatch(s) { next() }
        }
    }

    /** Plays every macro of the player's selected profiles, one after another. */
    private inner class Playlist {
        var state = 0 // 0 stopped, 1 playing, 2 paused
        var loopAll = false
        private var list: List<Macro> = emptyList()
        private var idx = 0
        private var cur: Runner? = null

        fun play() {
            if (state == 1) return
            if (state == 2) { state = 1; cur?.resume(); playerRestyle?.invoke(); return }
            list = Store.macros.filter { it.profileId in Store.playSelected }
            if (list.isEmpty()) { toast("No macros in the selected profiles"); return }
            idx = 0; state = 1
            playerRestyle?.invoke()
            runNext()
        }

        private fun runNext() {
            if (state == 0) return
            if (idx >= list.size) {
                if (loopAll) idx = 0 else { stop(); return }
            }
            val m = list[idx++]
            val r = Runner(m, true) { h.postDelayed({ if (state != 0) runNext() }, 50) }
            cur = r
            r.start()
        }

        fun pause() {
            if (state != 1) return
            state = 2; cur?.paused = true; playerRestyle?.invoke()
        }

        fun stop() {
            state = 0; cur?.stop(); cur = null; playerRestyle?.invoke()
        }
    }

    /** A finger went down somewhere on screen (seen through the privileged helper). Starts "don't block" macros. */
    fun onPrivTouch(action: Int, nx: Int, ny: Int) {
        if (action != 0 || !barOn || !enabled || editing) return
        val size = screenSize()
        val w = size.first.toFloat()
        val hh = size.second.toFloat()
        val u = nx / 10000f
        val v = ny / 10000f
        @Suppress("DEPRECATION")
        val rot = wm.defaultDisplay.rotation
        val x: Float
        val y: Float
        when (rot) {
            Surface.ROTATION_90 -> { x = v * w; y = (1f - u) * hh }
            Surface.ROTATION_180 -> { x = (1f - u) * w; y = (1f - v) * hh }
            Surface.ROTATION_270 -> { x = (1f - v) * w; y = u * hh }
            else -> { x = u * w; y = v * hh }
        }
        for (m in Store.macros.filter { it.profileId in Store.selected && it.touch == 1 }) {
            val b = buttons[m.id] ?: continue
            val p = b.tag as? WindowManager.LayoutParams ?: continue
            if (x >= p.x && x <= p.x + p.width && y >= p.y && y <= p.y + p.height) {
                toggleRun(m)
                break
            }
        }
    }

    private fun dispatch(s: Step, done: () -> Unit) {
        if (Priv.ready) { Priv.perform(s, done); return }
        val b = GestureDescription.Builder()
        if (s.type == "swipe") {
            val path = Path().apply {
                moveTo(s.x1.toFloat(), s.y1.toFloat()); lineTo(s.x2.toFloat(), s.y2.toFloat())
            }
            b.addStroke(GestureDescription.StrokeDescription(path, 0, s.ms.coerceAtLeast(1)))
        } else {
            val n = s.n.coerceIn(1, 10)
            val hold = s.ms.coerceAtLeast(1)
            for (i in 0 until n) {
                val path = Path().apply { moveTo(s.x1.toFloat(), s.y1.toFloat()) }
                b.addStroke(GestureDescription.StrokeDescription(path, i * (hold + s.gap.coerceAtLeast(10)), hold))
            }
        }
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { done() }
            override fun onCancelled(d: GestureDescription?) { done() }
        }, null)
        if (!ok) h.postDelayed({ done() }, 100)
    }

    // ---------------- Picking points on screen ----------------

    /**
     * Swipe/tap point picker made of small separate windows (no full-screen layer, the game stays visible):
     * draggable numbered markers (1 = start, 2 = end), a thin non-touchable line window, and draggable
     * Save / Cancel buttons. Save returns the marker centers as screen coordinates.
     */
    fun pickPoints(count: Int, initial: List<Pair<Int, Int>>, returnToApp: Boolean, cb: (List<Pair<Int, Int>>) -> Unit) {
        if (picking || count < 1) return
        picking = true
        val size = screenSize()
        val sw = size.first
        val sh = size.second
        val r = dp(22)

        class Mk(val view: TextView, val p: WindowManager.LayoutParams) {
            var offX = 0
            var offY = 0
        }
        val mks = mutableListOf<Mk>()
        fun cx(m: Mk) = m.p.x + m.offX + r
        fun cy(m: Mk) = m.p.y + m.offY + r

        // thin line between the markers (does not take touches)
        val line = LineView(this)
        val pl = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        pl.flags = pl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.addView(line, pl)
        pickerWins.add(line)
        fun updateLine() {
            if (mks.size >= 2) {
                line.set(cx(mks[0]).toFloat(), cy(mks[0]).toFloat(), cx(mks[1]).toFloat(), cy(mks[1]).toFloat())
            }
        }

        // instruction text (does not take touches)
        val info = TextView(this).apply {
            text = if (count == 1) "Drag the marker to the tap point, then press Save"
            else "Drag 1 (start) and 2 (end) where you want, then press Save"
            setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = roundBg(0xDD1B1F27.toInt(), dp(10))
        }
        val pi = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        pi.flags = pi.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        pi.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        pi.y = dp(90)
        wm.addView(info, pi)
        pickerWins.add(info)

        fun finish() {
            pickerWins.toList().forEach { rm(it) }
            pickerWins.clear()
            picking = false
            if (returnToApp) startActivity(
                appIntent(MacroEditorActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        }

        for (i in 0 until count) {
            val def = initial.getOrNull(i)
                ?: Pair(sw / 2, sh / 2 + (if (i == 0) dp(80) else -dp(80)))
            val tv = TextView(this).apply {
                text = (i + 1).toString(); gravity = Gravity.CENTER; textSize = 16f
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == 0) 0xFF2FA84F.toInt() else 0xFFC62828.toInt())
                    setStroke(dp(2), Color.WHITE)
                }
            }
            val p = lp(r * 2, r * 2)
            p.x = def.first - r; p.y = def.second - r
            val mk = Mk(tv, p)
            mks.add(mk)
            wm.addView(tv, p)
            pickerWins.add(tv)
            tv.post {
                val loc = IntArray(2)
                tv.getLocationOnScreen(loc)
                mk.offX = loc[0] - p.x; mk.offY = loc[1] - p.y
                if (mk.offX != 0 || mk.offY != 0) {
                    p.x -= mk.offX; p.y -= mk.offY
                    try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
                }
                updateLine()
            }
            attachDragFull(tv, tv, p, null, { updateLine() }, { updateLine() })
        }

        val save = TextView(this).apply {
            text = "Save"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            setPadding(dp(26), dp(12), dp(26), dp(12))
            background = roundBg(0xFF2FA84F.toInt(), dp(10))
        }
        val cancel = TextView(this).apply {
            text = "Cancel"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            setPadding(dp(26), dp(12), dp(26), dp(12))
            background = roundBg(0xFFC62828.toInt(), dp(10))
        }
        val ps = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        ps.x = maxOf(0, sw / 2 - dp(140)); ps.y = maxOf(0, sh - dp(200))
        val pc = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
        pc.x = maxOf(0, sw / 2 + dp(10)); pc.y = ps.y
        wm.addView(save, ps); pickerWins.add(save)
        wm.addView(cancel, pc); pickerWins.add(cancel)
        attachDrag(save, save, ps, {
            val res = mks.map { Pair(cx(it), cy(it)) }
            finish()
            cb(res)
        }) {}
        attachDrag(cancel, cancel, pc, { finish() }) {}
        h.postDelayed({ clampAll() }, 300)
    }

    // ---------------- Recording ----------------

    fun startRecording(macroId: String) {
        if (recorder != null) return
        val m = Store.macros.find { it.id == macroId } ?: return
        val steps = mutableListOf<Step>()
        var lastEnd = 0L; var t0 = 0L; var dx = 0f; var dy = 0f
        val root = FrameLayout(this)
        root.setBackgroundColor(0x22FF0000)
        val stop = TextView(this).apply {
            text = "\u25A0 Stop recording"; setTextColor(Color.WHITE); textSize = 14f
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = roundBg(0xDDC62828.toInt(), dp(10))
        }
        root.addView(stop, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ).apply { topMargin = dp(40) })
        stop.setOnClickListener {
            rm(root); recorder = null
            m.steps.addAll(steps)
            Store.save()
            toast("Recorded ${steps.size} actions")
        }
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    t0 = SystemClock.uptimeMillis(); dx = e.rawX; dy = e.rawY
                    if (lastEnd > 0 && t0 - lastEnd >= 30) steps.add(Step("wait", ms = t0 - lastEnd))
                }
                MotionEvent.ACTION_UP -> {
                    val now = SystemClock.uptimeMillis()
                    val dur = (now - t0).coerceIn(20L, 10000L)
                    if (hypot(e.rawX - dx, e.rawY - dy) < 25f) {
                        steps.add(Step("tap", dx.toInt(), dy.toInt(), ms = dur))
                    } else {
                        steps.add(Step("swipe", dx.toInt(), dy.toInt(), e.rawX.toInt(), e.rawY.toInt(), dur))
                    }
                    lastEnd = now
                }
            }
            true
        }
        wm.addView(root, lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT))
        recorder = root
    }
}

/** Draws the line between the start and end markers (screen coordinates) while picking a swipe. */
class LineView(ctx: Context) : View(ctx) {
    private var x1 = 0f
    private var y1 = 0f
    private var x2 = 0f
    private var y2 = 0f
    private var on = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = ctx.dp(3).toFloat()
        style = Paint.Style.STROKE
        alpha = 200
    }

    fun set(a: Float, b: Float, c: Float, d: Float) {
        x1 = a; y1 = b; x2 = c; y2 = d; on = true
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (!on) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        canvas.drawLine(x1 - loc[0], y1 - loc[1], x2 - loc[0], y2 - loc[1], paint)
    }
}
