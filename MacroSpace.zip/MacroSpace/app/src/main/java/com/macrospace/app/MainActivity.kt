package com.macrospace.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var listBox: LinearLayout
    private lateinit var privText: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        Priv.init(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(36), dp(16), dp(24))
        }
        root.addView(label("Macro Space", 28f, Color.WHITE, true))
        root.addView(label("Game macros with profiles", 13f, C_SUB))

        // Status card
        val status = card()
        val srow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        statusDot = View(this)
        srow.addView(statusDot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(10) })
        statusText = label("", 14f)
        srow.addView(statusText)
        status.addView(srow)
        status.addView(btn("Open accessibility settings", true) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(status, cardLp())

        // Privileged mode card
        val pv = card()
        pv.addView(label("Privileged mode (like GG's wireless debugging)", 16f, Color.WHITE, true))
        pv.addView(label(
            "Lets \"Don't block\" macros work for real: the game keeps your touches while the macro runs, " +
                "and macro taps are injected without cancelling your finger. Needs the free Shizuku app " +
                "started once with Wireless debugging (same pairing idea GG uses).", 12f, C_SUB))
        privText = label("", 14f, Color.WHITE, true)
        pv.addView(privText)
        pv.addView(rowOf(
            btn("Get Shizuku") {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
            },
            btn("Open Shizuku") {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i == null) toast("Shizuku is not installed") else startActivity(i)
            }
        ))
        pv.addView(btn("Connect", true) {
            Priv.connect(this)
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 1500)
        })
        root.addView(pv, cardLp())

        // Overlays card
        val ov = card()
        ov.addView(label("Overlays", 16f, Color.WHITE, true))
        ov.addView(rowOf(
            btn("Keymap overlay") {
                val s = MacroService.instance
                if (s == null) toast("Turn on Macro Space in Accessibility settings first") else s.showOverlay()
            },
            btn("Hide") { MacroService.instance?.hideOverlay() }
        ))
        ov.addView(rowOf(
            btn("Player overlay") {
                val s = MacroService.instance
                if (s == null) toast("Turn on Macro Space in Accessibility settings first") else s.showPlayer()
            },
            btn("Hide") { MacroService.instance?.hidePlayer() }
        ))
        ov.addView(btn("Overlay size, colors and texts") {
            val v = buildOverlayStyleEditor(this, { MacroService.instance?.rebuildBars() }, {})
            AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(v) })
                .setPositiveButton("Done", null).show()
        })
        root.addView(ov, cardLp())

        // Profiles card
        val pc = card()
        pc.addView(label("Profiles", 16f, Color.WHITE, true))
        pc.addView(rowOf(btn("Show profiles \u25BE") { showPicker() }, btn("Manage") { manageProfiles() }))
        root.addView(pc, cardLp())

        // Macros
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Macros", 18f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(btn("+ New macro", true) { startActivity(Intent(this, MacroEditorActivity::class.java)) })
        root.addView(head, cardLp())
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)

        setContentView(ScrollView(this).apply { setBackgroundColor(C_BG); addView(root) })
    }

    private fun cardLp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = MacroService.instance != null
        statusText.text = if (on) "Accessibility service is ON" else "Accessibility service is OFF"
        statusDot.background = roundBg(if (on) 0xFF2FA84F.toInt() else 0xFFC62828.toInt(), dp(6))
        privText.text = "Status: " + Priv.status
        privText.setTextColor(if (Priv.ready) 0xFF2FA84F.toInt() else Color.WHITE)
        listBox.removeAllViews()
        val vis = Store.macros.filter { it.profileId in Store.selected }
        if (vis.isEmpty()) listBox.addView(label("No macros in the selected profiles yet.", 13f, C_SUB))
        for (m in vis) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = roundBg(C_CARD, dp(12))
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            row.addView(View(this).apply { background = roundBg(argb(m.color, 255), dp(8)) },
                LinearLayout.LayoutParams(dp(16), dp(16)).apply { rightMargin = dp(12) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(label(m.name, 16f, Color.WHITE, true))
            col.addView(label(
                Store.profileName(m.profileId) + " \u00B7 " + m.steps.size + " steps" +
                        (if (m.loop) " \u00B7 loop" else if (m.repeat > 1) " \u00B7 x" + m.repeat else ""),
                12f, C_SUB
            ))
            row.addView(col)
            row.setOnClickListener {
                startActivity(Intent(this, MacroEditorActivity::class.java).putExtra("id", m.id))
            }
            row.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("Delete \"" + m.name + "\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        Store.macros.remove(m); Store.save()
                        MacroService.instance?.refreshButtons(); refresh()
                    }.setNegativeButton("Cancel", null).show()
                true
            }
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }

    private fun showPicker() {
        val v = buildProfilePicker(this, Store.selected) { MacroService.instance?.refreshButtons() }
        AlertDialog.Builder(this).setView(v).setPositiveButton("Done", null)
            .setOnDismissListener { refresh() }.show()
    }

    private fun manageProfiles() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val dlg = AlertDialog.Builder(this).setTitle("Manage profiles")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Close", null).create()
        fun render() {
            box.removeAllViews()
            for (p in Store.profiles.toList()) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                r.addView(label(p.name, 16f), LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(btn("Rename") {
                    prompt("Rename profile", p.name) { p.name = it; Store.save(); render() }
                })
                r.addView(btn("Delete") {
                    if (Store.profiles.size <= 1) { toast("You need at least one profile"); return@btn }
                    Store.profiles.remove(p)
                    val target = Store.profiles[0]
                    Store.macros.filter { it.profileId == p.id }.forEach { it.profileId = target.id }
                    Store.selected.remove(p.id)
                    Store.playSelected.remove(p.id)
                    if (Store.selected.isEmpty()) Store.selected.add(target.id)
                    Store.save(); MacroService.instance?.refreshButtons(); render()
                })
                box.addView(r)
            }
            box.addView(btn("+ Add profile", true) {
                prompt("New profile", "Profile ${Store.profiles.size + 1}") {
                    Store.profiles.add(Profile(name = it)); Store.save(); render()
                }
            })
        }
        render()
        dlg.setOnDismissListener { refresh() }
        dlg.show()
    }
}
