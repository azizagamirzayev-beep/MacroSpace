package com.macrospace.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

val C_BG = 0xFF0F1115.toInt()
val C_CARD = 0xFF1B1F27.toInt()
val C_CARD2 = 0xFF2A303B.toInt()
val C_ACCENT = 0xFFFF8A3D.toInt()
val C_SUB = 0xFF9AA3B2.toInt()

fun textWatcher(f: (String) -> Unit) = object : TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
}

fun Context.label(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
    TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.btn(t: String, filled: Boolean = false, click: () -> Unit) = Button(this).apply {
    text = t
    isAllCaps = false
    stateListAnimator = null
    setTextColor(if (filled) 0xFF1A1A1A.toInt() else Color.WHITE)
    background = roundBg(if (filled) C_ACCENT else C_CARD2, dp(10))
    setPadding(dp(12), dp(8), dp(12), dp(8))
    setOnClickListener { click() }
}

fun Context.field(hint: String, value: String = "", numeric: Boolean = false) = EditText(this).apply {
    setHint(hint)
    setText(value)
    setTextColor(Color.WHITE)
    setHintTextColor(C_SUB)
    setSingleLine()
    if (numeric) inputType = InputType.TYPE_CLASS_NUMBER
    background = roundBg(C_CARD2, dp(10))
    setPadding(dp(12), dp(10), dp(12), dp(10))
}

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = roundBg(C_CARD, dp(14))
    setPadding(dp(14), dp(12), dp(14), dp(12))
}

fun Context.rowOf(vararg views: View): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    for (v in views) {
        addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
        })
    }
}

fun Context.sliderRow(title: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View {
    val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    val tv = label("$title: $value", 12f, C_SUB)
    val sb = SeekBar(this)
    sb.max = max - min
    sb.progress = value - min
    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            tv.text = "$title: ${p + min}"
            if (fromUser) onChange(p + min)
        }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    box.addView(tv)
    box.addView(sb)
    return box
}

/** RGB sliders (+ optional opacity slider) with a live swatch. alpha == null hides the opacity slider. */
fun Context.colorEditor(title: String, rgb: Int, alpha: Int?, onChange: (Int, Int) -> Unit): View {
    var r = (rgb shr 16) and 255
    var g = (rgb shr 8) and 255
    var b = rgb and 255
    var a = alpha ?: 255
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(8), 0, dp(6))
    }
    val sw = View(this)
    fun cur() = (r shl 16) or (g shl 8) or b
    fun paint() { sw.background = roundBg(argb(cur(), a), dp(6)) }
    fun upd() { paint(); onChange(cur(), a) }
    box.addView(label(title, 14f, Color.WHITE, true))
    box.addView(sw, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(24)))
    box.addView(sliderRow("Red", 0, 255, r) { r = it; upd() })
    box.addView(sliderRow("Green", 0, 255, g) { g = it; upd() })
    box.addView(sliderRow("Blue", 0, 255, b) { b = it; upd() })
    if (alpha != null) box.addView(sliderRow("Opacity", 0, 255, a) { a = it; upd() })
    paint()
    return box
}

/** Editor for the look of one macro button (color, transparency, size, corners, text). */
fun buildMacroStyleEditor(
    ctx: Context, m: Macro, onChanged: () -> Unit, onEditSteps: () -> Unit, onClose: () -> Unit
): LinearLayout {
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
    }
    box.addView(ctx.label("Macro button: ${m.name}", 16f, Color.WHITE, true))
    val e = ctx.field("Button text (empty = macro name)", m.label)
    e.addTextChangedListener(textWatcher { m.label = it; onChanged() })
    box.addView(e)
    box.addView(ctx.colorEditor("Color and transparency", m.color, m.alpha) { c, a ->
        m.color = c; m.alpha = a; onChanged()
    })
    box.addView(ctx.sliderRow("Width", 30, 220, m.w) { m.w = it; onChanged() })
    box.addView(ctx.sliderRow("Height", 30, 220, m.h) { m.h = it; onChanged() })
    box.addView(ctx.sliderRow("Corner roundness %", 0, 100, m.corner) { m.corner = it; onChanged() })
    box.addView(ctx.btn("Edit steps in app", true) { onEditSteps() })
    box.addView(ctx.btn("Close") { onClose() })
    return box
}

/** Editor for colors, transparency and texts of the keymap bar and the player bar. */
fun buildOverlayStyleEditor(ctx: Context, onChanged: () -> Unit, onClose: () -> Unit): LinearLayout {
    val u = Store.ui
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
    }
    fun changed() { Store.save(); onChanged() }
    fun tf(title: String, value: String, set: (String) -> Unit) {
        box.addView(ctx.label(title, 12f, C_SUB))
        val e = ctx.field("", value)
        e.addTextChangedListener(textWatcher { set(it); changed() })
        box.addView(e)
    }
    box.addView(ctx.label("Overlay style", 16f, Color.WHITE, true))
    box.addView(ctx.sliderRow("Bar size %", 50, 250, u.barScale) { u.barScale = it; changed() })
    box.addView(ctx.colorEditor("Bar color and transparency", u.barColor, u.barAlpha) { c, a ->
        u.barColor = c; u.barAlpha = a; changed()
    })
    box.addView(ctx.colorEditor("Text color", u.textColor, null) { c, _ -> u.textColor = c; changed() })
    box.addView(ctx.colorEditor("Highlight color", u.accent, null) { c, _ -> u.accent = c; changed() })
    box.addView(ctx.label("Texts", 14f, Color.WHITE, true))
    tf("Edit button", u.lblEdit) { u.lblEdit = it }
    tf("Done button", u.lblDone) { u.lblDone = it }
    tf("Enable button", u.lblEnable) { u.lblEnable = it }
    tf("Disable button", u.lblDisable) { u.lblDisable = it }
    tf("Profiles button", u.lblProfiles) { u.lblProfiles = it }
    tf("Play button", u.lblPlay) { u.lblPlay = it }
    tf("Pause button", u.lblPause) { u.lblPause = it }
    tf("Stop button", u.lblStop) { u.lblStop = it }
    box.addView(ctx.btn("Close", true) { onClose() })
    return box
}
