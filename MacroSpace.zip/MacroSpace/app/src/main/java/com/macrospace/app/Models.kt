package com.macrospace.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class Profile(val id: String = UUID.randomUUID().toString(), var name: String)

/**
 * type: "tap" | "swipe" | "wait".
 * tap: n = number of taps (1 single, 2 double, 3 triple), ms = hold time of each tap, gap = pause between taps.
 * swipe: ms = duration. wait: ms = delay.
 */
class Step(
    var type: String, var x1: Int = 0, var y1: Int = 0,
    var x2: Int = 0, var y2: Int = 0, var ms: Long = 50,
    var n: Int = 1, var gap: Long = 60
) {
    fun toJson(): JSONObject = JSONObject().put("t", type).put("x1", x1).put("y1", y1)
        .put("x2", x2).put("y2", y2).put("ms", ms).put("n", n).put("gap", gap)

    fun label(): String = when (type) {
        "tap" -> when {
            n == 2 -> "Double tap ($x1, $y1)"
            n == 3 -> "Triple tap ($x1, $y1)"
            n > 3 -> "Tap x$n ($x1, $y1)"
            ms >= 400 -> "Hold ($x1, $y1) for ${ms}ms"
            else -> "Tap ($x1, $y1)"
        }
        "swipe" -> "Swipe ($x1, $y1) to ($x2, $y2) in ${ms}ms"
        else -> "Wait ${ms}ms"
    }

    companion object {
        fun from(o: JSONObject) = Step(
            o.getString("t"), o.optInt("x1"), o.optInt("y1"),
            o.optInt("x2"), o.optInt("y2"), o.optLong("ms", 50),
            o.optInt("n", 1), o.optLong("gap", 60)
        )
    }
}

class Macro(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    var profileId: String,
    val steps: MutableList<Step> = mutableListOf(),
    var repeat: Int = 1,
    var loop: Boolean = false,
    var btnX: Int = -1,
    var btnY: Int = -1,
    var color: Int = 0x2F6FDB,
    var alpha: Int = 204,
    var w: Int = 60,
    var h: Int = 60,
    var corner: Int = 100,
    var label: String = "",
    var touch: Int = 0 // 0 block original taps, 1 tap through then run, 2 pass through only
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name)
        .put("profile", profileId).put("repeat", repeat).put("loop", loop)
        .put("bx", btnX).put("by", btnY)
        .put("color", color).put("alpha", alpha).put("w", w).put("h", h)
        .put("corner", corner).put("label", label).put("touch", touch)
        .put("steps", JSONArray().also { a -> steps.forEach { a.put(it.toJson()) } })

    companion object {
        fun from(o: JSONObject): Macro {
            val m = Macro(
                id = o.getString("id"), name = o.getString("name"), profileId = o.getString("profile"),
                repeat = o.optInt("repeat", 1), loop = o.optBoolean("loop"),
                btnX = o.optInt("bx", -1), btnY = o.optInt("by", -1),
                color = o.optInt("color", 0x2F6FDB), alpha = o.optInt("alpha", 204),
                w = o.optInt("w", 60), h = o.optInt("h", 60),
                corner = o.optInt("corner", 100), label = o.optString("label", ""),
                touch = o.optInt("touch", 0)
            )
            val a = o.optJSONArray("steps")
            if (a != null) for (i in 0 until a.length()) m.steps.add(Step.from(a.getJSONObject(i)))
            return m
        }
    }
}

/** Look and texts of the floating bars. Colors are RGB ints (no alpha). */
class UiSettings {
    var barColor = 0xB5733A
    var barAlpha = 221
    var textColor = 0xFFFFFF
    var accent = 0xE0701F
    var barScale = 100
    var lblEdit = "Edit keymap"
    var lblDone = "Done"
    var lblEnable = "Enable"
    var lblDisable = "Disable"
    var lblProfiles = "Profiles"
    var lblPlay = "\u25B6"
    var lblPause = "\u275A\u275A"
    var lblStop = "\u25A0"
    var barX = -1
    var barY = -1
    var playX = -1
    var playY = -1

    fun toJson(): JSONObject = JSONObject()
        .put("barColor", barColor).put("barAlpha", barAlpha).put("textColor", textColor).put("accent", accent).put("barScale", barScale)
        .put("lblEdit", lblEdit).put("lblDone", lblDone).put("lblEnable", lblEnable)
        .put("lblDisable", lblDisable).put("lblProfiles", lblProfiles)
        .put("lblPlay", lblPlay).put("lblPause", lblPause).put("lblStop", lblStop)
        .put("barX", barX).put("barY", barY).put("playX", playX).put("playY", playY)

    fun load(o: JSONObject) {
        barColor = o.optInt("barColor", barColor); barAlpha = o.optInt("barAlpha", barAlpha)
        textColor = o.optInt("textColor", textColor); accent = o.optInt("accent", accent)
        barScale = o.optInt("barScale", 100)
        lblEdit = o.optString("lblEdit", lblEdit); lblDone = o.optString("lblDone", lblDone)
        lblEnable = o.optString("lblEnable", lblEnable); lblDisable = o.optString("lblDisable", lblDisable)
        lblProfiles = o.optString("lblProfiles", lblProfiles)
        lblPlay = o.optString("lblPlay", lblPlay); lblPause = o.optString("lblPause", lblPause)
        lblStop = o.optString("lblStop", lblStop)
        barX = o.optInt("barX", -1); barY = o.optInt("barY", -1)
        playX = o.optInt("playX", -1); playY = o.optInt("playY", -1)
    }
}

object Store {
    private var sp: SharedPreferences? = null
    val profiles = mutableListOf<Profile>()
    val macros = mutableListOf<Macro>()
    val selected = mutableSetOf<String>()      // profiles whose macro buttons are shown
    val playSelected = mutableSetOf<String>()  // profiles played by the player overlay
    val ui = UiSettings()

    fun init(c: Context) {
        if (sp != null) return
        sp = c.applicationContext.getSharedPreferences("data", Context.MODE_PRIVATE)
        try {
            val j = sp!!.getString("json", null)
            if (j != null) {
                val o = JSONObject(j)
                val pa = o.getJSONArray("profiles")
                for (i in 0 until pa.length()) {
                    val p = pa.getJSONObject(i)
                    profiles.add(Profile(p.getString("id"), p.getString("name")))
                }
                val ma = o.getJSONArray("macros")
                for (i in 0 until ma.length()) macros.add(Macro.from(ma.getJSONObject(i)))
                val sa = o.getJSONArray("selected")
                for (i in 0 until sa.length()) selected.add(sa.getString(i))
                val pl = o.optJSONArray("playSel")
                if (pl != null) for (i in 0 until pl.length()) playSelected.add(pl.getString(i))
                val u = o.optJSONObject("ui")
                if (u != null) ui.load(u)
            }
        } catch (e: Exception) { }
        if (profiles.isEmpty()) {
            val p = Profile(name = "Profile 1")
            profiles.add(p); selected.add(p.id)
        }
        val ids = profiles.map { it.id }.toSet()
        selected.retainAll(ids)
        playSelected.retainAll(ids)
        if (playSelected.isEmpty()) playSelected.addAll(selected)
    }

    fun save() {
        val o = JSONObject()
        o.put("profiles", JSONArray().also { a ->
            profiles.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }
        })
        o.put("macros", JSONArray().also { a -> macros.forEach { a.put(it.toJson()) } })
        o.put("selected", JSONArray().also { a -> selected.forEach { a.put(it) } })
        o.put("playSel", JSONArray().also { a -> playSelected.forEach { a.put(it) } })
        o.put("ui", ui.toJson())
        sp?.edit()?.putString("json", o.toString())?.apply()
    }

    fun profileName(id: String) = profiles.find { it.id == id }?.name ?: "?"
}
