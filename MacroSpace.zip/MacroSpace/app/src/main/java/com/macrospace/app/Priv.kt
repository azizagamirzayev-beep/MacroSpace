package com.macrospace.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

/**
 * "Privileged mode": connects to the helper process that Shizuku starts with ADB (wireless debugging)
 * privileges. Gives real touch watching (the game keeps receiving your touches) and real injected taps.
 */
object Priv {
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var app: Context? = null
    private var inited = false
    private var svc: IUserService? = null

    @Volatile var ready = false
    @Volatile var status = "Not connected"

    private val listener = object : ITouchListener.Stub() {
        override fun onTouch(action: Int, slot: Int, x: Int, y: Int) {
            main.post { MacroService.instance?.onPrivTouch(action, x, y) }
        }
    }

    private val conn = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) { status = "Helper process did not start"; return }
            val s = IUserService.Stub.asInterface(binder)
            svc = s
            status = "Starting touch access..."
            exec.execute {
                val r = try { s.start(listener) } catch (e: Throwable) { "start failed: " + e.message }
                ready = r == "OK"
                status = if (ready) "Connected" else r
                main.post { MacroService.instance?.refreshButtons() }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null; ready = false; status = "Helper disconnected"
            main.post { MacroService.instance?.refreshButtons() }
        }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
        try {
            Shizuku.addBinderReceivedListenerSticky { main.post { autoConnect() } }
            Shizuku.addBinderDeadListener {
                ready = false; svc = null; status = "Shizuku stopped"
                main.post { MacroService.instance?.refreshButtons() }
            }
            Shizuku.addRequestPermissionResultListener { _, result ->
                if (result == PackageManager.PERMISSION_GRANTED) {
                    main.post { bind() }
                } else {
                    status = "Permission denied in Shizuku"
                }
            }
        } catch (e: Throwable) {
            status = "Shizuku library error: " + e.message
        }
    }

    private fun autoConnect() {
        try {
            if (svc == null && Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) bind()
        } catch (_: Throwable) {}
    }

    fun connect(ctx: Context) {
        init(ctx)
        try {
            if (!Shizuku.pingBinder()) { status = "Shizuku is not running. Open Shizuku and start it first."; return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    status = "Permission was denied. Allow Macro Space inside the Shizuku app."
                    return
                }
                status = "Waiting for your permission..."
                Shizuku.requestPermission(100)
                return
            }
            if (svc == null) bind() else status = if (ready) "Connected" else status
        } catch (e: Throwable) {
            status = "Shizuku error: " + e.message
        }
    }

    private fun bind() {
        val c = app ?: return
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(c.packageName, UserService::class.java.name))
                .daemon(false).processNameSuffix("priv").debuggable(false).version(1)
            Shizuku.bindUserService(args, conn)
            status = "Connecting..."
        } catch (e: Throwable) {
            status = "Bind failed: " + e.message
        }
    }

    /** Runs one step with injected touches (does not cancel the user's own touch). Calls done on the main thread. */
    fun perform(s: Step, done: () -> Unit) {
        val service = svc
        if (service == null || !ready) { main.post { done() }; return }
        exec.execute {
            try {
                if (s.type == "swipe") service.swipe(s.x1, s.y1, s.x2, s.y2, s.ms.toInt())
                else service.tap(s.x1, s.y1, s.ms.toInt(), s.n, s.gap.toInt())
            } catch (e: Throwable) {
                ready = false; status = "Lost connection: " + e.message
            }
            main.post { done() }
        }
    }
}
