package com.macrospace.app

import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView

/** Multi-select profile dropdown content: search box + Select all + checkbox list. Works on any selection set. */
fun buildProfilePicker(ctx: Context, sel: MutableSet<String>, onChanged: () -> Unit): LinearLayout {
    val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(10), ctx.dp(10), ctx.dp(10), ctx.dp(10))
        background = roundBg(0xFF1B1F27.toInt(), ctx.dp(10))
    }
    val search = EditText(ctx).apply {
        hint = "Search profiles"
        setHintTextColor(0xFF9AA3B2.toInt())
        setTextColor(Color.WHITE)
        setSingleLine()
    }
    val all = CheckBox(ctx).apply { text = "Select all"; setTextColor(Color.WHITE) }
    val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val sv = ScrollView(ctx).apply { addView(list) }
    root.addView(search)
    root.addView(all)
    root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(220)))

    var building = false
    fun filtered() = Store.profiles.filter {
        it.name.contains(search.text.toString().trim(), ignoreCase = true)
    }
    fun syncAll() {
        building = true
        val f = filtered()
        all.isChecked = f.isNotEmpty() && f.all { it.id in sel }
        building = false
    }
    fun rebuild() {
        building = true
        list.removeAllViews()
        for (p in filtered()) {
            list.addView(CheckBox(ctx).apply {
                text = p.name + "  (" + Store.macros.count { it.profileId == p.id } + ")"
                setTextColor(Color.WHITE)
                isChecked = p.id in sel
                setOnCheckedChangeListener { _, c ->
                    if (!building) {
                        if (c) sel.add(p.id) else sel.remove(p.id)
                        Store.save(); onChanged(); syncAll()
                    }
                }
            })
        }
        building = false
        syncAll()
    }
    all.setOnCheckedChangeListener { _, c ->
        if (!building) {
            for (p in filtered()) if (c) sel.add(p.id) else sel.remove(p.id)
            Store.save(); onChanged(); rebuild()
        }
    }
    search.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) { rebuild() }
    })
    rebuild()
    return root
}
