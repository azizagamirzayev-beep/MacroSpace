package com.macrospace.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.widget.EditText
import android.widget.Toast

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

fun roundBg(color: Int, r: Int): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = r.toFloat() }

fun argb(rgb: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (rgb and 0xFFFFFF)
fun opaque(rgb: Int): Int = argb(rgb, 255)

fun Activity.prompt(title: String, initial: String, ok: (String) -> Unit) {
    val e = EditText(this).apply { setText(initial); setSingleLine() }
    AlertDialog.Builder(this).setTitle(title).setView(e)
        .setPositiveButton("OK") { _, _ ->
            val t = e.text.toString().trim()
            if (t.isNotEmpty()) ok(t)
        }
        .setNegativeButton("Cancel", null).show()
}
