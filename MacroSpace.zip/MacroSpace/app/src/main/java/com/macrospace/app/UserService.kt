package com.macrospace.app

import android.content.Context
import android.os.Process
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.FileInputStream
import java.lang.reflect.Method
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

/**
 * Runs in a separate process with shell (ADB) privileges, started through Shizuku.
 * 1) watches the touchscreen read-only, so the game still gets the user's touches;
 * 2) injects taps and swipes through the system input manager.
 */
class UserService() : IUserService.Stub() {
    constructor(context: Context) : this()

    private val lock = Any()

    @Volatile private var listener: ITouchListener? = null
    @Volatile private var reading = false
    private val streams = mutableListOf<FileInputStream>()
    private var inputManager: Any? = null
    private var injectMethod: Method? = null

    override fun destroy() {
        stopReading()
        System.exit(0)
    }

    override fun start(l: ITouchListener?): String {
        listener = l
        val err1 = initInjector()
        val err2 = startReader()
        return if (err1 == null && err2 == null) "OK"
        else listOfNotNull(err1, err2).joinToString("; ")
    }

    override fun stopReading() {
        reading = false
        synchronized(streams) {
            streams.forEach { try { it.close() } catch (_: Throwable) {} }
            streams.clear()
        }
    }

    // ---------------- injection ----------------

    private fun initInjector(): String? {
        if (injectMethod != null) return null
        val names = listOf("android.hardware.input.InputManagerGlobal", "android.hardware.input.InputManager")
        for (cn in names) {
            try {
                val cls = Class.forName(cn)
                val gi = cls.getDeclaredMethod("getInstance")
                gi.isAccessible = true
                val inst = gi.invoke(null) ?: continue
                val m = cls.methods.firstOrNull {
                    it.name == "injectInputEvent" && it.parameterTypes.size == 2 && it.parameterTypes[0] == InputEvent::class.java
                } ?: cls.methods.firstOrNull {
                    it.name == "injectInputEvent" && it.parameterTypes.size == 3 && it.parameterTypes[0] == InputEvent::class.java
                } ?: continue
                m.isAccessible = true
                inputManager = inst
                injectMethod = m
                return null
            } catch (_: Throwable) {
            }
        }
        return "cannot access the system input injection"
    }

    private fun inject(ev: MotionEvent): Boolean {
        val m = injectMethod ?: return false
        return try {
            val r = if (m.parameterTypes.size == 3) m.invoke(inputManager, ev, 0, -1) else m.invoke(inputManager, ev, 0)
            (r as? Boolean) ?: true
        } catch (_: Throwable) {
            false
        }
    }

    private fun touch(downTime: Long, action: Int, x: Float, y: Float): Boolean {
        val props = arrayOf(MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_FINGER })
        val coords = arrayOf(MotionEvent.PointerCoords().apply { this.x = x; this.y = y; pressure = 1f; size = 1f })
        val ev = MotionEvent.obtain(
            downTime, SystemClock.uptimeMillis(), action, 1, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        val ok = inject(ev)
        ev.recycle()
        return ok
    }

    override fun tap(x: Int, y: Int, holdMs: Int, count: Int, gapMs: Int) {
        synchronized(lock) {
            val n = count.coerceIn(1, 10)
            for (i in 0 until n) {
                val t = SystemClock.uptimeMillis()
                touch(t, MotionEvent.ACTION_DOWN, x.toFloat(), y.toFloat())
                Thread.sleep(holdMs.coerceAtLeast(1).toLong())
                touch(t, MotionEvent.ACTION_UP, x.toFloat(), y.toFloat())
                if (i < n - 1) Thread.sleep(gapMs.coerceAtLeast(10).toLong())
            }
        }
    }

    override fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, durMs: Int) {
        synchronized(lock) {
            val t = SystemClock.uptimeMillis()
            val dur = durMs.coerceAtLeast(1)
            touch(t, MotionEvent.ACTION_DOWN, x1.toFloat(), y1.toFloat())
            val steps = (dur / 10).coerceIn(1, 600)
            val stepMs = (dur / steps).toLong().coerceAtLeast(1)
            for (i in 1..steps) {
                Thread.sleep(stepMs)
                val f = i.toFloat() / steps
                touch(t, MotionEvent.ACTION_MOVE, x1 + (x2 - x1) * f, y1 + (y2 - y1) * f)
            }
            touch(t, MotionEvent.ACTION_UP, x2.toFloat(), y2.toFloat())
        }
    }

    // ---------------- watching touches ----------------

    private class Dev(val path: String, val maxX: Int, val maxY: Int, val direct: Boolean)

    private fun findDevices(): List<Dev> {
        val p = Runtime.getRuntime().exec(arrayOf("getevent", "-pl"))
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor()
        val res = mutableListOf<Dev>()
        for (b in text.split("add device")) {
            val path = Regex("(/dev/input/event\\d+)").find(b)?.value ?: continue
            val mx = Regex("ABS_MT_POSITION_X\\s*:.*?max (\\d+)").find(b)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            val my = Regex("ABS_MT_POSITION_Y\\s*:.*?max (\\d+)").find(b)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            res.add(Dev(path, mx, my, b.contains("INPUT_PROP_DIRECT")))
        }
        val direct = res.filter { it.direct }
        return if (direct.isNotEmpty()) direct else res
    }

    private fun startReader(): String? {
        if (reading) return null
        val devs = try { findDevices() } catch (e: Throwable) { return "getevent failed: $e" }
        if (devs.isEmpty()) return "no touchscreen found"
        var error: String? = null
        val opened = mutableListOf<Pair<Dev, FileInputStream>>()
        for (d in devs) {
            try { opened.add(Pair(d, FileInputStream(d.path))) }
            catch (e: Throwable) { error = "cannot open ${d.path}: ${e.message}" }
        }
        if (opened.isEmpty()) return error ?: "cannot open the touchscreen"
        reading = true
        synchronized(streams) { opened.forEach { streams.add(it.second) } }
        for (o in opened) thread(isDaemon = true) { readLoop(o.first, o.second) }
        return null
    }

    private fun emit(action: Int, slot: Int, rx: Int, ry: Int, d: Dev) {
        val l = listener ?: return
        val nx = (rx.toLong() * 10000 / d.maxX.coerceAtLeast(1)).toInt()
        val ny = (ry.toLong() * 10000 / d.maxY.coerceAtLeast(1)).toInt()
        try { l.onTouch(action, slot, nx, ny) } catch (_: Throwable) {}
    }

    private fun readLoop(d: Dev, fis: FileInputStream) {
        val size = if (Process.is64Bit()) 24 else 16
        val buf = ByteArray(size * 32)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        val xs = IntArray(32)
        val ys = IntArray(32)
        val down = BooleanArray(32)
        val up = BooleanArray(32)
        var slot = 0
        try {
            while (reading) {
                val n = fis.read(buf)
                if (n <= 0) break
                var off = 0
                while (off + size <= n) {
                    val type = bb.getShort(off + size - 8).toInt() and 0xFFFF
                    val code = bb.getShort(off + size - 6).toInt() and 0xFFFF
                    val value = bb.getInt(off + size - 4)
                    off += size
                    if (type == 3) {
                        when (code) {
                            0x2f -> slot = value.coerceIn(0, 31)
                            0x39 -> if (value == -1) up[slot] = true else down[slot] = true
                            0x35 -> xs[slot] = value
                            0x36 -> ys[slot] = value
                        }
                    } else if (type == 0 && code == 0) {
                        for (s in 0 until 32) {
                            if (down[s]) { emit(0, s, xs[s], ys[s], d); down[s] = false }
                            if (up[s]) { emit(1, s, xs[s], ys[s], d); up[s] = false }
                        }
                    }
                }
            }
        } catch (_: Throwable) {
        }
    }
}
